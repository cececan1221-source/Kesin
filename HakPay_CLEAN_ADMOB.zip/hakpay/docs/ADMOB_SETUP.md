# HakPay AdMob

Bu proje Google Mobile Ads Flutter Plugin 9.x ile hazırlanmıştır.

## Test

Varsayılan olarak Google'ın resmi Android test App ID ve test Banner/Rewarded ID'leri kullanılır.
Bu nedenle ilk APK'da ayrıca AdMob hesabı veya kendi reklam birimi ID'leri gerekmez.

## Gerçek yayın

Yayınlamadan önce yetişkin hesap sahibi tarafından oluşturulmuş AdMob App ID ve reklam birimi ID'leri GitHub Actions Secrets olarak eklenmelidir:

- ADMOB_APP_ID
- ADMOB_REWARDED_ID
- ADMOB_BANNER_ID

Geliştirme sırasında production reklamları kullanmayın. Google test reklamları özellikle test içindir.
